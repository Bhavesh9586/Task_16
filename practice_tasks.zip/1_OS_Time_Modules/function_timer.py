# Task: Function Timer Decorator
